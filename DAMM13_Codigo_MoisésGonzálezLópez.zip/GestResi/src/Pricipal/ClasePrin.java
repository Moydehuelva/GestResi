
package Pricipal;

import Interfaz.Login;

/**
 *
 * @author moyde
 */
public class ClasePrin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Login log = new Login();
        log.setVisible(true);
    }

}
